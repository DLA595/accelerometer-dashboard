import requests
import json
import time
import random
from datetime import datetime

# Firebase Realtime Database URL
FIREBASE_URL = "https://accelodata-default-rtdb.firebaseio.com/accelerometer.json"

def generate_fake_data():
    """Generate random accelerometer data"""
    return {
        "x": round(random.uniform(-10, 10), 2),
        "y": round(random.uniform(-10, 10), 2),
        "z": round(random.uniform(8, 12), 2),  # Z typically has gravity component
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

def upload_to_firebase(data):
    """Upload data to Firebase"""
    # POST request creates a unique key automatically
    response = requests.post(FIREBASE_URL, json=data)
    
    if response.status_code == 200:
        print(f"Data uploaded successfully: {data}")
        print(f"Firebase generated key: {response.json()['name']}")
    else:
        print(f"Error uploading data: {response.status_code}")
        print(response.text)

def main():
    """Main function to generate and upload data at regular intervals"""
    print("Starting fake accelerometer data upload to Firebase...")
    print(f"Target URL: {FIREBASE_URL}")
    
    try:
        while True:
            # Generate fake data
            data = generate_fake_data()
            
            # Upload to Firebase
            upload_to_firebase(data)
            
            # Wait before next upload (1 second)
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\nProgram stopped by user.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()